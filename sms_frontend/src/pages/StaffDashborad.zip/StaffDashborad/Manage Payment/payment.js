import React, { useState,useEffect } from "react";
import {Card, Typography, Space, Col, Row, Input, DatePicker,
   Select, Button, Table, Tag, Progress,
   message
} from "antd";
import api from "../../../Api/indext";
import { SearchOutlined, ClockCircleOutlined,
} from "@ant-design/icons";
import PaymentDetail from "./view"
const { Title, Text } = Typography;
const { RangePicker } = DatePicker;

const Payment = () => {
  const [searchText, setSearchText] =useState("");
  const [selectedMonth, setSelectedMonth] =useState("");
  const [selectedYear, setSelectedYear] =useState("");
  const [selectedPaymentType,setSelectedPaymentType,] = useState("");
  const [openDrawer, setOpenDrawer] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [paymentData, setPaymentData] =
  useState([]);

const [loading, setLoading] =
  useState(false);
const handleViewDetail = (record) => {
  setSelectedPayment(record);
  setOpenDrawer(true);
};
  
   const fetchPayments = async () => {

  try {

    setLoading(true);

    const token =
      localStorage.getItem(
        "accessToken"
      );

    if (!token) {

      message.error(
        "No token found"
      );

      return;
    }

    const res = await api.get(
      "/payments",
      {
        headers: {
          Authorization:
            `Bearer ${token}`,
        },
      }
    );

    setPaymentData(
      res.data.list || []
    );

  } catch (error) {

    console.log(error);

    message.error(
      "Failed to fetch payments"
    );

  } finally {

    setLoading(false);

  }
};
useEffect(() => {
  fetchPayments();
}, []);
  // FILTER LOGIC
  const filteredData = paymentData.filter(
    (item) => {
      // SEARCH
      const matchSearch =
        item.StudentName
          .toLowerCase()
          .includes(
            searchText.toLowerCase()
          );
      // MONTH
      const matchMonth =
        selectedMonth === ""? true: item.month === selectedMonth;
      // YEAR
      const matchYear =
        selectedYear === ""? true: item.year === selectedYear;
      // PAYMENT TYPE
      const matchPaymentType =
        selectedPaymentType === ""? true: item.paymentType ===  selectedPaymentType;
      return (
        matchSearch &&
        matchMonth &&
        matchYear &&
        matchPaymentType
      );
    }
  );

  // PROGRESS DATA
  const paidCount = filteredData.filter(
    (item) => item.status === "Paid"
  ).length;

  const progressPercent =
    filteredData.length > 0
      ? Math.round(
          (paidCount /filteredData.length) *100): 0;
  // TABLE COLUMNS
  const columns = [
    {
      title: "Name",
      dataIndex: "StudentName",
      render: (text) => (
        <Text strong>{text}</Text>
      ),
    },

    {
      title: "Fee Name",
      dataIndex: "FeeName",
    },

    {
      title: "Payment Type",
      dataIndex: "PaymentType"
    },

    {
      title: "Month",
      dataIndex: "Months",
    },

    {
      title: "Amount",
      dataIndex: "Amount",
      render: (text) => (
        <Text
          strong
          style={{
            color: "#1677ff",
          }}
        >
          {text}
        </Text>
      ),
    },

    {
      title: "Status",
      dataIndex: "Status",
      render: (status) => (
        <Tag
          color={
            status === "Paid"
              ? "green"
              : "orange"
          }
        >
          {status}
        </Tag>
      ),
    },
     {
      title: "Payment Date",
      dataIndex: "PaymentDate",
    },
  ];

  return (
    <div style={{ padding: 0 }}>
      {/* PAGE TITLE */}
      <div
        style={{
          marginBottom: 10,
        }}
      >
        <Title level={2}>Payment Overview</Title>
        <Text type="secondary">
          School payment management dashboard
        </Text>
      </div>
      {/* SUMMARY CARDS */}
      <Row gutter={[16, 16]}
        style={{marginBottom: 20,}}
      >
        {/* PROGRESS CARD */}
        <Col xs={24} md={12}>
          <Card
            style={{
              borderRadius: 20,
              border: "none",
              boxShadow:"0 4px 12px rgba(0,0,0,0.08)",
            }}
          >
            <Space  direction="vertical" style={{width: "100%",}}>
              <Text strong>
                {selectedPaymentType? `${selectedPaymentType} Payment Progress`
                  : "Overall Payment Progress"}
              </Text>
              <Progress
                percent={progressPercent}
                status="active"
                strokeColor={
                  progressPercent >= 80
                    ? "#52c41a"
                    : progressPercent >= 50
                    ? "#1677ff"
                    : "#ff4d4f"
                }
              />
              <Text type="secondary">
                {paidCount} of{" "}
                {filteredData.length} students
                already paid
              </Text>
            </Space>
          </Card>
        </Col>
        {/* PENDING CARD */}
        <Col xs={24} md={12}>
          <Card
            style={{
              width: "100%",
              height: "100%",
              borderRadius: 20,
              border: "none",
              boxShadow:"0 4px 12px rgba(0,0,0,0.08)",
              display: "flex",
              alignItems: "center"  
            }}
          >
            <Space align="center">
              <ClockCircleOutlined
                style={{
                  fontSize: 35,
                  color: "#faad14",
                }}
              />
              <div>
                <Title
                  level={4}
                  style={{
                    margin: 0,
                  }}
                >
                  {filteredData.filter(
                      (item) =>item.status ==="Pending").length
                  }{" "}
                  Pending Payments
                </Title>
                <Text type="secondary">
                  Need follow-up
                </Text>
              </div>
            </Space>
          </Card>
        </Col>
      </Row>

      {/* FILTER CARD */}
      <Card
        style={{
          borderRadius: 20,
          border: "none",
          boxShadow:
            "0 4px 12px rgba(0,0,0,0.08)",
        }}
        bodyStyle={{
          padding: 24,
        }}
      >
        <Row gutter={[16, 16]}>
          {/* SEARCH */}
          <Col xs={24} sm={24} md={8}>
            <Text strong>
              Student Name
            </Text>

            <Input
              size="large"
              placeholder="Search student..."
              prefix={<SearchOutlined />}
              value={searchText}
              onChange={(e) =>
                setSearchText(
                  e.target.value
                )
              }
              style={{
                marginTop: 8,
                borderRadius: 10,
              }}
            />
          </Col>

          {/* DATE */}
          <Col xs={24} sm={12} md={5}>
            <Text strong>
              Date Range
            </Text>

            <RangePicker
              size="large"
              style={{
                width: "100%",
                marginTop: 8,
              }}
            />
          </Col>

          {/* MONTH */}
          <Col xs={24} sm={12} md={4}>
            <Text strong>Month</Text>

            <Select
              size="large"
              placeholder="Select Month"
              value={selectedMonth}
              onChange={(value) =>
                setSelectedMonth(value)
              }
              allowClear
              style={{
                width: "100%",
                marginTop: 8,
              }}
              options={[
                {value: "January",label: "January",},
                {value: "February",label: "February",},
                {value: "March", label: "March",},
                {value: "April",label: "April",},
                {value: "May",label: "May",},
                {value: "June",label: "June",},
                {value: "July",label: "July",},
                { value: "August",label: "August",},
                {value: "September",label: "September",},
                {value: "October",label: "October",},
                { value: "November",label: "November",},
                {value: "December",label: "December",},
              ]}
            />
          </Col>

          {/* YEAR */}
          <Col xs={24} sm={12} md={3}>
            <Text strong>Year</Text>

            <Select
              size="large"
              placeholder="Year"
              value={selectedYear}
              onChange={(value) =>
                setSelectedYear(value)
              }
              allowClear
              style={{
                width: "100%",
                marginTop: 8,
              }}
              options={[
                {value: "2024",label: "2024",},
                {value: "2025",label: "2025",},
                {value: "2026",label: "2026",},
              ]}
            />
          </Col>
          {/* PAYMENT TYPE */}
          <Col xs={24} sm={12} md={4}>
            <Text strong>
              Payment Type
            </Text>

            <Select
              size="large"
              placeholder="Payment Type"
              value={selectedPaymentType}
              onChange={(value) =>
                setSelectedPaymentType(
                  value
                )
              }
              allowClear
              style={{
                width: "100%",
                marginTop: 8,
              }}
              options={[
                {
                  value: "Monthly",
                  label: "Monthly",
                },

                {
                  value: "Quarterly",
                  label: "Quarterly",
                },

                {
                  value: "Semester",
                  label: "Semester",
                },

                {
                  value: "Annual",
                  label: "Annual",
                },
              ]}
            />
          </Col>
        </Row>
      </Card>

      {/* TABLE */}
      <Card
        style={{
          marginTop: 20,
          borderRadius: 20,
          border: "none",
          boxShadow:
            "0 4px 12px rgba(0,0,0,0.08)",
        }}
      >
        {/* HEADER */}
        <div
          style={{
            display: "flex",
            justifyContent:
              "space-between",
            alignItems: "center",
            marginBottom: 20,
            flexWrap: "wrap",
            gap: 10,
          }}
        >
          <div>
            <Title
              level={4}
              style={{
                margin: 0,
              }}
            >
              Student Payments
            </Title>

            <Text type="secondary">
              Recent payment transactions
            </Text>
          </div>
        </div>

        {/* TABLE */}
        <Table
            columns={columns}
            dataSource={filteredData}
            loading={loading}
            rowKey="Id"
            pagination={{
              pageSize: 5,
            }}
          />
        <PaymentDetail
            open={openDrawer}
            onClose={() => setOpenDrawer(false)}
            payment={selectedPayment}
          />
      </Card>
    </div>
    
  );
};

export default Payment;