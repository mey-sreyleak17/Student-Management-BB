import React,{useState,useEffect,useCallback} from "react";
import "../../../styles/report.css";
import {
  Row,
  Col,
  Card,
  Table,
  Input,
  Button,
  DatePicker,
  Select,
  message,
  Tag
} from "antd";
import api from "../../../Api/indext";
import {
  SearchOutlined,
  FilePdfOutlined,
  FileExcelOutlined,
} from "@ant-design/icons";

const { RangePicker } = DatePicker;

export default function PaymentReport() {
      const [payments, setPayments] =useState([]);
      const [loading, setLoading] = useState(false);
      const [searchText, setSearchText] =useState("");
      const [selectedClass, setSelectedClass] =useState("");
      const [dateRange, setDateRange] =useState([]);
      const [classes, setClasses] =useState([]);


 const fetchPayments =async () => {

  try {

    setLoading(true);

    const token =
      localStorage.getItem(
        "accessToken"
      );

    const params = {};

    if (selectedClass) {

      params.classId =
        selectedClass;
    }

    if (
      dateRange &&
      dateRange.length === 2
    ) {

      params.startDate =
        dateRange[0]
        .format("YYYY-MM-DD");

      params.endDate =
        dateRange[1]
        .format("YYYY-MM-DD");
    }
     console.log(selectedClass);

      console.log(dateRange);

    console.log(params);
    const res = await api.get(
      "/payments/report",
      {
        headers: {
          Authorization:
            `Bearer ${token}`,
        },
        params,
      }
    );

    setPayments(
      res.data.list || []
    );

  } catch (error) {

    console.log(error);

  } finally {

    setLoading(false);
  }

};
const fetchClasses = async () => {

  try {

    const token =
      localStorage.getItem(
        "accessToken"
      );

    const res = await api.get(
      "/classes/select",
      {
        headers: {
          Authorization:
            `Bearer ${token}`,
        },
      }
    );

    setClasses(
      res.data || []
    );

  } catch (error) {

    console.log(error);

  }
};

const handleExportExcel =
  async () => {

  try {

    const token =
      localStorage.getItem(
        "accessToken"
      );

    const response =
      await api.get(
        "/payments/export-excel",
        {
          responseType: "blob",

          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

    const url =
      window.URL.createObjectURL(
        new Blob([response.data])
      );

    const link =
      document.createElement("a");

    link.href = url;

    link.setAttribute(
      "download",
      "payment_report.xlsx"
    );

    document.body.appendChild(
      link
    );

    link.click();

    link.remove();

  } catch (error) {

    console.log(error);

    message.error(
      "Export excel failed"
    );
  }
};

const handleExportPDF =
  async () => {

  try {

    const token =
      localStorage.getItem(
        "accessToken"
      );

    const response =
      await api.get(
        "/payments/export-pdf",
        {
          responseType: "blob",

          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

    const url =
      window.URL.createObjectURL(
        new Blob([response.data])
      );

    const link =
      document.createElement("a");

    link.href = url;

    link.setAttribute(
      "download",
      "payment_report.pdf"
    );

    document.body.appendChild(
      link
    );

    link.click();

    link.remove();

  } catch (error) {

    console.log(error);

    message.error(
      "Export PDF failed"
    );
  }
};
useEffect(() => {
  fetchPayments();
  fetchClasses();
}, []);

const searchedPayments =
  payments.filter((item) =>

    item.StudentName
      ?.toLowerCase()
      .includes(
        searchText.toLowerCase()
      )
);
  const columns = [
    {
      title: "Receipt No",
      dataIndex: "Id",
    },
    {
      title: "Student Name",
      dataIndex: "StudentName",
    },
    {
      title: "Fee Name",
      dataIndex: "FeeName",
    },
    {
      title: "Amount",
      dataIndex: "Amount",
    },
    {
      title:"PaymentMethod",
      dataIndex:"PaymentMethod"
    }
    ,
    {
      title: "Payment Date",
      dataIndex: "PaymentDate",
    },
    {
  title: "Status",
  dataIndex: "Status",

  render: (status) => (

    <Tag
      color={
        status === "Paid"
          ? "green"
          : "orange"
      }
    >
      {status}
    </Tag>
  ),
}
  ];

  return (
    <div className="report-page">
      <Card className="report-card">
        <div className="report-header">
          <h2>Payment Report</h2>

          <div className="report-actions">
            <Button
           icon={<FilePdfOutlined />}
            onClick={handleExportPDF}
      >
        Export PDF
        </Button>

        <Button
            icon={<FileExcelOutlined />}
            onClick={handleExportExcel}
          >
           Export Excel
            </Button>
          </div>
        </div>

        <Row gutter={16}>
          <Col span={6}>
            <Input
              placeholder="Search student..."
              prefix={<SearchOutlined />}
              value={searchText}
              onChange={(e) =>
                setSearchText(
              e.target.value
                )
              }
            />
          </Col>

          <Col span={6}>
            <Select
              style={{ width: "100%" }}
              placeholder="Select Class"
              value={selectedClass}
              onChange={(value) =>
             setSelectedClass(value)
             }
  allowClear
>

  {classes.map(item => (

    <Select.Option
        key={item.Id}
          value={item.Id}
      >
     {item.ClassName}
  </Select.Option>

  ))}

    </Select>
          </Col>

          <Col span={8}>
            <RangePicker
              style={{ width: "100%" }}
              onChange={(dates) =>
             setDateRange(dates)
            }
            />
          </Col>

          <Col span={4}>
            <Button
             type="primary"
             block
            onClick={fetchPayments}
          >
         Filter
        </Button>
          </Col>
        </Row>

        <Table
            style={{ marginTop: 20 }}
            columns={columns}
            dataSource={searchedPayments}
            loading={loading}
            rowKey="Id"
            pagination={{
              pageSize: 5,
            }}
          />
      </Card>
    </div>
  );
}