import React,{useState,useEffect} from "react";
import "../../../styles/report.css";
import {
  Row,
  Col,
  Card,
  Table,
  Input,
  Button,
  Select,
  message
} from "antd";
import api from "../../../Api/indext";
import {
  SearchOutlined,
  FilePdfOutlined,
  FileExcelOutlined,
} from "@ant-design/icons";

export default function StudentReport() {
            const [students, setStudents] =useState([]);
            const [loading, setLoading] = useState(false);
            const [searchText, setSearchText] =useState("");
            const [selectedClass, setSelectedClass] =useState("");
            const [dateRange, setDateRange] =useState([]);
            const [classes, setClasses] =useState([]);

        const fetchClasses = async () => {

  try {

    const token =
      localStorage.getItem(
        "accessToken"
      );

    const res = await api.get(
      "/classes/select",
      {
        headers: {
          Authorization:
            `Bearer ${token}`,
        },
      }
    );

    setClasses(
      res.data || []
    );

  } catch (error) {

    console.log(error);

  }
};

    const handleExportExcel =
  async () => {

  try {

    const token =
      localStorage.getItem(
        "accessToken"
      );

    const response =
      await api.get(
        "/students/export-excel",
        {
          responseType: "blob",

          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

    const url =
      window.URL.createObjectURL(
        new Blob([response.data])
      );

    const link =
      document.createElement("a");

    link.href = url;

    link.setAttribute(
      "download",
      "student_report.xlsx"
    );

    document.body.appendChild(
      link
    );

    link.click();

    link.remove();

  } catch (error) {

    console.log(error);

    message.error(
      "Export excel failed"
    );
  }
};

const fetchStudents =
  async () => {

  try {

    setLoading(true);

    const token =
      localStorage.getItem(
        "accessToken"
      );

    const params = {};

    if (selectedClass) {

      params.classId =
        selectedClass;
    }

    const res = await api.get(
      "/students/report",
      {
        headers: {
          Authorization:
            `Bearer ${token}`,
        },

        params,
      }
    );

    setStudents(
      res.data.list || []
    );

  } catch (error) {

    console.log(error);

  } finally {

    setLoading(false);
  }
};
const searchedStudents =
  students.filter((item) =>

     item.StudentName
      ?.toLowerCase()
      .includes(
        searchText.toLowerCase()
      )
);
const handleExportPDF =
  async () => {

  try {

    const token =
      localStorage.getItem(
        "accessToken"
      );

    const response =
      await api.get(
        "/students/export-pdf",
        {
          responseType: "blob",

          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

    const url =
      window.URL.createObjectURL(
        new Blob([response.data])
      );

    const link =
      document.createElement("a");

    link.href = url;

    link.setAttribute(
      "download",
      "student_report.pdf"
    );

    document.body.appendChild(
      link
    );

    link.click();

    link.remove();

  } catch (error) {

    console.log(error);

    message.error(
      "Export PDF failed"
    );
  }
};
useEffect(() => {
  fetchClasses();
  fetchStudents();
}, []);

 const columns = [

  {
    title: "Student ID",
    dataIndex: "Id",
  },

  {
    title: "Student Name",
    dataIndex: "StudentName",
  },

  {
    title: "Gender",
    dataIndex: "Gender",
  },

  {
    title: "Class",
    dataIndex: "ClassName",
  },

  {
    title: "Phone",
    dataIndex: "Phone",
  },
];
  return (
    <div className="report-page">
      <Card className="report-card">

        <div className="report-header">
          <h2>Student Report</h2>

          <div className="report-actions">
             <Button
           icon={<FilePdfOutlined />}
            onClick={handleExportPDF}
      >
        Export PDF
        </Button>

            <Button 
                 icon={<FileExcelOutlined />}
                 onClick={handleExportExcel}
            >
              Export Excel
            </Button>
          </div>
        </div>

        <Row gutter={16}>
          <Col span={8}>
            <Input
                          placeholder="Search student..."
                          prefix={<SearchOutlined />}
                          value={searchText}
                          onChange={(e) =>
                            setSearchText(
                          e.target.value
                            )
                          }
                   />
          </Col>

          <Col span={8}>
             <Select
                          style={{ width: "100%" }}
                          placeholder="Select Class"
                          value={selectedClass}
                          onChange={(value) =>
                         setSelectedClass(value)
                         }
              allowClear
            >
              {classes.map(item => (
                <Select.Option
                    key={item.Id}
                      value={item.Id}
                  >
                 {item.ClassName}
              </Select.Option>
              ))}
                </Select>
          </Col>

          <Col span={8}>
            <Button
                  type="primary"
                  block
                  onClick={fetchStudents}
                >
                 Filter
                </Button>
          </Col>
        </Row>

       <Table
          columns={columns}
          dataSource={searchedStudents}
          rowKey="Id"
          loading={loading}
          pagination={{
          pageSize: 5,
  }}
/>

      </Card>
    </div>
  );
}