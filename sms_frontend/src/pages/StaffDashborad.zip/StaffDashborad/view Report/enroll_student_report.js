import React,{useEffect,useState} from "react";
import {
  Row,
  Col,
  Card,
  Table,
  Button,
  Select,
  DatePicker,
  message
} from "antd";
import api from "../../../Api/indext";
import {
  FilePdfOutlined,
  FileExcelOutlined,
} from "@ant-design/icons";
import "../../../styles/report.css";
const { RangePicker } = DatePicker;


export default function EnrollmentReport() {

    const [enrollments,setEnrollments] = useState([]);
    const [academicYears,setAcademicYears] =useState([]);
    const [selectedAcademicYear,setSelectedAcademicYear] = useState(null);
    const [dateRange,setDateRange] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchText, setSearchText] =useState("");

 const fetchEnrollments =
  async () => {

  try {

    setLoading(true);

    const token =
      localStorage.getItem(
        "accessToken"
      );

    const params = {};

    if (
      selectedAcademicYear
    ) {

      params.academicYearId =
        selectedAcademicYear;
    }

    if (
      dateRange &&
      dateRange.length === 2
    ) {

      params.startDate =
        dateRange[0]
        .format("YYYY-MM-DD");

      params.endDate =
        dateRange[1]
        .format("YYYY-MM-DD");
    }

    const res = await api.get(
      "/enrollments/report",
      {
        headers: {
          Authorization:
            `Bearer ${token}`,
        },

        params,
      }
    );

    setEnrollments(
      res.data.list || []
    );

  } catch (error) {

    console.log(error);

  } finally {

    setLoading(false);
  }
};


useEffect(() => {

  fetchEnrollments();

  fetchYears();

}, []);
 const fetchYears = async () => {

    try {

      const res = await api.get(
        "/academic/select"
      );

      setAcademicYears(res.data);

    } catch (error) {

      console.error(error);

      message.error(
        "Failed to load academic years"
      );

    }

  };


const searchedStudents =
  enrollments.filter((item) =>

     item.Name
      ?.toLowerCase()
      .includes(
        searchText.toLowerCase()
      )
);

 const handleExportExcel =
  async () => {

  try {

    const token =
      localStorage.getItem(
        "accessToken"
      );

    const response =
      await api.get(
        "/enrollments/export-excel",
        {
          responseType: "blob",

          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

    const url =
      window.URL.createObjectURL(
        new Blob([response.data])
      );

    const link =
      document.createElement("a");

    link.href = url;

    link.setAttribute(
      "download",
      "enrollment_report.xlsx"
    );

    document.body.appendChild(
      link
    );

    link.click();

    link.remove();

  } catch (error) {

    console.log(error);

    message.error(
      "Export excel failed"
    );
  }
};

const handleExportPDF =
  async () => {

  try {

    const token =
      localStorage.getItem(
        "accessToken"
      );

    const response =
      await api.get(
        "/enrollments/export-pdf",
        {
          responseType: "blob",

          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

    const url =
      window.URL.createObjectURL(
        new Blob([response.data])
      );

    const link =
      document.createElement("a");

    link.href = url;

    link.setAttribute(
      "download",
      "enrollment_report.pdf"
    );

    document.body.appendChild(
      link
    );

    link.click();

    link.remove();

  } catch (error) {

    console.log(error);

    message.error(
      "Export PDF failed"
    );
  }
};
  const columns = [

  {
    title: "Enrollment No",
    dataIndex: "Id",
  },

  {
    title: "Student Name",
    dataIndex: "StudentName",
  },

  {
    title: "Class",
    dataIndex: "ClassName",
  },

  {
    title: "Academic Year",
    dataIndex: "Name",
  },

  {
    title: "Enrollment Date",
    dataIndex: "EnrollDate",
  },

  {
    title: "Status",
    dataIndex: "Status",
  },
];
  return (
    <div className="report-page">

      <Card className="report-card">

        <div className="report-header">
          <h2>Enrollment Student Report</h2>

          <div className="report-actions">
            <Button
  icon={<FilePdfOutlined />}
  onClick={handleExportPDF}
>
  Export PDF
</Button>

        <Button
  icon={<FileExcelOutlined />}
  onClick={handleExportExcel}
>
  Export Excel
</Button>
          </div>
        </div>

        <Row gutter={16}>
          <Col span={8}>
           <Select
  placeholder="Select Academic Year"
  style={{ width: "100%" }}
  value={selectedAcademicYear}
  onChange={(value) =>
    setSelectedAcademicYear(value)
  }
  allowClear
>

  {academicYears.map(item => (

    <Select.Option
      key={item.Id}
      value={item.Id}
    >
      {item.Name}
    </Select.Option>

  ))}

    </Select>
          </Col>

          <Col span={8}>
            <RangePicker
              style={{ width: "100%" }}
            />
          </Col>

          <Col span={8}>
            <Button type="primary" block>
              Filter
            </Button>
          </Col>
        </Row>

        <Table
        columns={columns}
        dataSource={searchedStudents}
        rowKey="Id"
        loading={loading}
        pagination={{
         pageSize: 5,
  }}
/>

      </Card>
    </div>
  );
}