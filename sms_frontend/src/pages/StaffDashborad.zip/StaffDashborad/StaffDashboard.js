import  { useState,useEffect } from "react";
// import "./layout.css";
import bb  from "../../assets/bb.jpg"
import { Dropdown, Avatar } from "antd";
//import { UserOutlined } from "@ant-design/icons";
import { Outlet, useNavigate } from "react-router-dom";
import {HomeOutlined,MenuUnfoldOutlined, MenuFoldOutlined, UserOutlined, UsergroupAddOutlined, CreditCardOutlined, SettingOutlined,
        BankOutlined,CalendarOutlined,BellOutlined,GlobalOutlined,LogoutOutlined,SearchOutlined} from "@ant-design/icons";
import { Button, Layout, Menu, theme, Input, Space, message,Modal} from "antd";
import api from "../../Api/indext";
const { Header, Sider, Content, Footer } = Layout;

const StaffDashboard = () => {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [ setLoading] = useState(false);
  // Add 'currentLang' to your states
const [currentLang, setCurrentLang] = useState(localStorage.getItem("language") || "en");
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

const handleLogout =  async() => {
      try {
         const token = localStorage.getItem("accessToken");
      if (!token) {
        message.error("No token found, please log in");
        setLoading(false);
        return;
      }
     const res = await api.post(
         "/auth/logout",
        {},
         { headers: { Authorization: `Bearer ${token}` } }
        );
      message.success("Logout Successfully");
         navigate("/"); // redirect
      } catch (error) {
        message.error("Logout Failed");
      }
    };

    const confirmLogout = () => {
  Modal.confirm({
    title: "Confirm Logout",
    content: "Do you really want to log out?",
    okText: "Yes",
    cancelText: "No",
    onOk: () => handleLogout(), // 👈 call your existing logout function
  });
};

  useEffect(() => {
  const token = localStorage.getItem("accessToken");
  if (!token) return;

  api.get("/auth/me", {
    headers: { Authorization: `Bearer ${token}` }
  })
  .then(res => setUser(res.data))
  .catch(err => console.error(err));
}, []);

const items = [
  {
    key: "profile",
    label: user?.name || user?.email || localStorage.getItem("userEmail"),
  }
];
//change language
const handleChange = (lang) => {
  localStorage.setItem("language", lang);
  setCurrentLang(lang); // This triggers the re-render!
  message.success(`Language changed to ${lang === 'en' ? 'English' : 'Khmer'}`);
};

  /*
   {
              key: 'subject',
              icon: <BookOutlined style={{fontSize:20}}/>,
              label: "Subject",
            },
           {
              key:'grade',
              label:'Grade',
              icon:<MenuUnfoldOutlined style={{fontSize:20}}/>
            },
  */
const items_lang = [
    {
      key: "en",
      label: "English",
      onClick: () => handleChange("en"),
    },
    {
      key: "kh",
      label: "ខ្មែរ",
      onClick: () => handleChange("kh"),
    },
  ];
const translations = {
    'en': {
        'welcome': 'Welcome to Student Management',
        'dashboard': 'Dashboard',
        'class': 'Class Management',
        'students': ' Management Students',
        'teachers': ' Management Teachers',
        'fee':'Managegement Fee',
        'attendance': 'View Attendance ',
        'payment': 'Management Payment',
        'data': 'Management Data',
        'report': 'View Report ',


    },
    'kh': {
        'welcome': 'ស្វាគមន៍មកកាន់ការគ្រប់គ្រងសិស្ស',
        'dashboard': 'ផ្ទាំងគ្រប់គ្រង',
        'class': 'ការគ្រប់គ្រងថ្នាក់រៀន',
        'students': 'ការគ្រប់គ្រងសិស្ស',
        'teachers': 'ការគ្រប់គ្រងគ្រូបង្រៀន',
        'attendance': 'ការគ្រប់គ្រងវត្តមាន',
        'payment': 'ការតាមដានការបង់ប្រាក់',
        'report': 'ពិនិត្យមើលរបាយការណ៍',
        'fee':"ការគ្រប់គ្រងលើfee",
        'data':"ការគ្រប់គ្រងទិន្និន័យ"

    }
};
  return (
    <Layout style={{ minHeight: "100vh" }}>
      {/* SIDEBAR */}
      <Sider
        collapsible
        collapsed={collapsed}
        onCollapse={setCollapsed}
        width={260}
      >
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={["dashboard"]}
          defaultOpenKeys={["user"]}
          onClick={({ key }) => navigate(key)}
          items={[
    {
      key: 'dashboard',
      icon: <HomeOutlined style={{fontSize:20}}/>,
      label: translations[currentLang].dashboard,
    },
    {
      key: "class",
      icon: <BankOutlined style={{fontSize:20}}/>,
      label: translations[currentLang].class,
    },
    {
      key: "student",
      icon: <UsergroupAddOutlined style={{fontSize:20}}/>,
      label: translations[currentLang].students,
    },
    {
      key: "teacher",
      icon: <UserOutlined style={{fontSize:20}}/>,
      label: translations[currentLang].teachers,
    },
    {
      key: "fee",
      icon: <SettingOutlined style={{fontSize:20}}/>,
      label: translations[currentLang].fee,
    },
    {
      key: "attendance",
      icon: <CalendarOutlined style={{fontSize:20}}/>,
      label: translations[currentLang].attendance,
    },
    {
      key: "payment",
      icon: <CreditCardOutlined style={{fontSize:20}}/>,
      label: translations[currentLang].payment,
    },
    {
      key: "data",
      icon: <SettingOutlined style={{fontSize:20}}/>,
      label: translations[currentLang].data,
    },
    {
      key: "report",
      icon: <SettingOutlined style={{fontSize:20}}/>,
      label: translations[currentLang].report,
    },
  ]}
        />
      </Sider>
      <Layout>
        {/* HEADER */}
        <Header
          style={{
            background: colorBgContainer,
            padding: "0 20px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            height:"100px"
          }}
        >
          {/* LEFT */}
          <Space size="large">
            <Button
              type="text"
              icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
              onClick={() => setCollapsed(!collapsed)}
              style={{fontSize:20,width:50, height: 50}}
            />
            <img
              src={bb}
              alt="logo"
              style={{ height: 70,marginTop:25 }}/>
            <h2 style={{ margin: 0, color: "#16c5ff", fontSize: "23px" }}>
               {translations[currentLang].welcome}
              </h2>
          </Space>

          {/* RIGHT */}
          <Space size="middle">
            <Input
              placeholder="Search..."
              prefix={<SearchOutlined />}
              style={{ width: 200 }}
            />

         <Dropdown menu={{ items: items_lang }} placement="bottom" trigger={["click"]}>
             <Button
                    type="text"
                    icon={<GlobalOutlined />}
                    style={{ fontSize: 20 }}
              />
          </Dropdown>

            <Button type="text" icon={<BellOutlined />} style={{fontSize:20}}/>

        <Dropdown menu={{ items }} placement="bottomCenter">
              <Avatar style={{ backgroundColor: "#87d068" }}>
                     {user?.name
                      ? user.name[0].toUpperCase()
                      : user?.email
                      ? user.email[0].toUpperCase()
                      : <UserOutlined />}
              </Avatar>
        </Dropdown>

            <Button danger icon={<LogoutOutlined />}
               onClick={confirmLogout}
             />
          </Space>
        </Header>
        {/* CONTENT */}
        <Content
          style={{
            margin: 16,
            padding: 24,
            background: colorBgContainer,
            borderRadius: borderRadiusLG,
          }}
        >
          <Outlet />
        </Content>

        {/* FOOTER */}
        <Footer style={{ textAlign: "center" }}>
          © Bright Brain School 2026
        </Footer>
      </Layout>
    </Layout>
  );
}
export default StaffDashboard;