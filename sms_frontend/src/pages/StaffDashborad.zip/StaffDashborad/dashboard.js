import React from "react";
import { Card, Row, Col, Typography } from "antd";
import {
  UserOutlined,SolutionOutlined,CheckCircleOutlined,CalendarOutlined,BarChartOutlined,IdcardOutlined,ScheduleOutlined
} from "@ant-design/icons";
import { useNavigate } from "react-router-dom";

const { Title,Text } = Typography;

//  Dashboard Menu 
const dashboardItems = [
  { key: 'teacher/class',
    title: "Student List",
    desc:'View student information',
     icon: <UserOutlined style={{ fontSize: 30 }} /> },
  { key: 'teacher/class',
     title: "Score & Grade", 
     desc:'Manage score by month and view ',
     icon: <SolutionOutlined style={{ fontSize: 30 }} /> },
  { key: 'teacher/attendance', 
    title: "Take Attendance",
    desc:'View student information',
     icon: <CheckCircleOutlined style={{ fontSize: 30 }} /> },
  { key: 'teacher/attendance',
    title: "Student Attendance", 
    desc:'View student information',
    icon: <CalendarOutlined style={{ fontSize: 30 }} /> },
  {  key: 'teacher/schedule',
    title: "Schedule",
    desc:'View student information',
     icon: <ScheduleOutlined  style={{ fontSize: 30 }} /> },
  {  key: 'teacher/report',
     title: "Report", 
     desc:'View student information',
     icon: <BarChartOutlined style={{ fontSize: 30 }} /> },
  { key: 'teacher/profile',
    title: "Profile",
    desc:'View student information',
    icon: <IdcardOutlined style={{ fontSize: 30 }} />,},
];

const Dashboard = () => {
  const navigate = useNavigate();
return(
  <div style={{ padding: 0 }}>
      {/* Title */}
      <Title level={2} style={{ marginBottom: 0}}>
        Quick Action
      </Title>
      <Text type="secondary" style={{ marginBottom: 20, display: "block" }}>
        Access all main features quickly
      </Text>

      <Row gutter={[20, 20]}>
        {dashboardItems.map((item, index) => (
          <Col xs={24} sm={12} md={8} lg={6} key={index}>
            <Card
              hoverable
              onClick={() => navigate(`/${item.key}`)}
              className="dashboard-card"
              style={{
                borderRadius: 16,
                height: 160,
                padding: 10,
                background: "#ffffff",
              }}
              bodyStyle={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              {/* Icon */}
              <div className="icon-box">{item.icon}</div>

              {/* Title */}
              <Text strong style={{ fontSize: 16 }}>
                {item.title}
              </Text>

              {/* Description */}
              <Text type="secondary" style={{ fontSize: 13 }}>
                {item.desc}
              </Text>
            </Card>
          </Col>
        ))}
      </Row>

      {/*  Animation */}
      <style>
      {`
          .dashboard-card {
            transition: all 0.25s ease;
            border: 1px solid #f0f0f0;
          }

          .dashboard-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 12px 30px rgba(0,0,0,0.12);
          }

          .icon-box {
            width: 55px;
            height: 55px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1890ff, #40a9ff);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: white;
            margin-bottom: 10px;
          }
        `}
      </style>
    </div>
  );
};

export default Dashboard;
