import React,{useEffect,useState} from "react";
import {Row,Col,Card,Input,Select,Button,Typography,message,Space,Modal} from "antd";
import {PlusOutlined,DeleteOutlined, EditOutlined,EyeOutlined} from "@ant-design/icons";
import TeacherForm from "./teacherForm";
import api from "../../../Api/indext";
import {Table} from "antd";

const { Title, Text } = Typography;
const { Search } = Input;


const TeacherManagement = () => {
    const [mode, setMode] = useState( "add"); // "add" or "update"
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [teachers, setTeachers] = useState([]);  // array, not object
    const [selectedTeacher, setSelectedTeacher] = useState(null);
    // Get all teachers
         const [teacherCount, setTeacherCount] = useState(0);
         const [searchTerm, setSearchTerm] = useState("");
         const [subjectFilter, setSubjectFilter] = useState("all");
         const [statusFilter, setStatusFilter] = useState("all");

const handleAddTeacher = async (formData) => {
  try {
    const token = localStorage.getItem("accessToken");
    if (!token) {
      message.error("No token found, please log in");
      return;
    }
    await api.post("/teacher", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${token}`,
      },
    });
    message.success("Teacher created successfully");
    setOpen(false);
    fetchTeacherCount();
    fetchTeachers();
  } catch (error) {
    console.error(error);
    message.error("Create failed");
  }
};
 useEffect(() => {
  fetchTeacherCount();
  fetchTeachers();
  }, []);

const fetchTeachers = async () => {
  try {
    const token = localStorage.getItem("accessToken");
    if (!token) {
      message.error("No token found, please log in");
      return;
    }

    const res = await api.get("/teacher", {
      headers: { Authorization: `Bearer ${token}` },
    });

    console.log("Teachers response:", res.data);

    // Use the list array from the response
    setTeachers(Array.isArray(res.data.list) ? res.data.list : []);
  } catch (err) {
    console.error("Error fetching teachers:", err);
    setTeachers([]); // fallback
  }
};
 const fetchTeacherCount=async()=>{
    setLoading(true);
  try {
       const token = localStorage.getItem("accessToken");
    if (!token) {
      message.error("No token found, please log in");
      setLoading(false);
      return;
    }

    const res = await api.get("/teacher/total", {
      headers: { Authorization: `Bearer ${token}` },
    });

    setTeacherCount(res.data.totalTeacher);
  } catch (error) {
     console.error("Error fetching Teacher Total:", error);
  } finally {
    setLoading(false);
  }
}
// Update teacher
const handleUpdate = async (formData) => {
  try {
    const token = localStorage.getItem("accessToken");
    await api.put(`/api/teacher/${selectedTeacher.Id}`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${token}`,
      },
    });
    message.success("Updated teacher successfully");
    setOpen(false);
    fetchTeacherCount();
  } catch (error) {
    console.error(error);
    message.error("Update failed");
  }
};
const confirmUpdate = (teachers) => {
  Modal.confirm({
    title: "Confirm Update",
    content: `Do you want to update ${teachers.Name}'s information?`,
    okText: "Yes",
    cancelText: "No",
    onOk: () => {
      setSelectedTeacher(teachers);
      setMode("update");
      setOpen(true);
    },
  });
};

// Delete teacher soure
const handleDelete = async (id) => {
  try {
    const token = localStorage.getItem("accessToken");
    await api.delete(`/api/teacher/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    message.success("Teacher deleted successfully");
    fetchTeacherCount();
  } catch (error) {
    console.error(error);
    message.error("Delete failed");
  }
};
const confirmDelete = (teachers) => {
  Modal.confirm({
    title: "Confirm Delete",
    content: `Do you want to delete student ${teachers.Name}?`,
    okText: "Yes",
    cancelText: "No",
    onOk: () => {
      setSelectedTeacher(teachers);
      handleDelete(teachers.Id);
    },
  });
};

 //  search + status filter done
  const filteredTeachers = teachers.filter((teacher) => {
  const term = searchTerm.toLowerCase();

  const matchesSearch =
    (teacher.Id?.toString().toLowerCase().includes(term)) ||
    (teacher.TeacherCode?.toString().toLowerCase().includes(term)) ||
    (teacher.KhmerName?.toLowerCase().includes(term));

  const matchesSubject =
    subjectFilter === "all" || teacher.Subject?.toLowerCase() === subjectFilter;

  const matchesStatus =
    statusFilter === "all" ||
    (statusFilter === "active" && teacher.Status?.toLowerCase() === "active") ||
    (statusFilter === "inactive" && teacher.Status?.toLowerCase() === "inactive");

  return matchesSearch && matchesSubject && matchesStatus;
});



const columns = [
  { title: "ID", dataIndex: "TeacherCode", key: "TeacherCode" },
  { title: "Name", dataIndex: "KhmerName", key: "KhmerName" },
  { title: "Shift", dataIndex: "Shift", key: "Shift" },
  { title: "Address", dataIndex: "Address", key: "Address" },
  { title: "Phone", dataIndex: "Phone", key: "Phone" },
   {
      title: "Actions",
      render: (teachers) => (
        <Space>
          <EyeOutlined
                style={{ color: "#1890ff" }}
            />
             <EditOutlined
               style={{ color: "#52c41a" }}
              onClick={() => confirmUpdate(teachers)}
               />
          <DeleteOutlined
                style={{ color: "red" }}
                 onClick={() => confirmDelete(teachers)}
          />
        </Space>
      ),
    }
];
  return (
    <div style={{ padding: 30 }}>

      {/* Header */}
      <Row justify="space-between" align="middle">
        <Col>
          <Title level={2}>Teacher Management</Title>
          <Text type="secondary">
            Manage teacher profiles and assignments
          </Text>
        </Col>

        <Col>
          <Button
                      type="primary"
                      icon={<PlusOutlined />}
                      onClick={() => {
                      setSelectedTeacher(null);
                        setMode("add");
                        setOpen(true);
                      }}
                        >
                     បញ្ចូលគ្រូថ្មី
          </Button>
        </Col>
      </Row>
      {/*MODAL */}
            <TeacherForm
            open={open}
            onCancel={() => {
                setOpen(false);
                setSelectedTeacher(null);
                setMode(null);
               }}
              onSubmit={mode === "update" ? handleUpdate : handleAddTeacher}
              initialValues={selectedTeacher}
              mode={mode}
/>

    {/* Statistics */}
<Row gutter={[16, 16]} style={{ marginTop: 25 }}>
  <Col span={6}>
    <Card style={{ padding: "12px", borderRadius: "8px", backgroundColor:"pink" }}>
      <Text style={{ fontSize: "14px" }}>Total Teachers</Text>
      <Title level={4} style={{ color: "#1677ff", margin: 0, fontSize:"25px" }}>
        {teacherCount}
      </Title>
    </Card>
  </Col>
   
   <Col span={6}>
    <Card style={{ padding: "12px", borderRadius: "8px", backgroundColor:"pink" }}>
      <Text style={{ fontSize: "14px" }}>Teachers level 1</Text>
      <Title level={4} style={{ color: "#1677ff", margin: 0, fontSize:"25px" }}>
       10
      </Title>
    </Card>
  </Col>
<Col span={6}>
    <Card style={{ padding: "12px", borderRadius: "8px", backgroundColor:"blanchedalmond" }}>
      <Text style={{ fontSize: "14px" }}>Teachers Level 2</Text>
      <Title level={4} style={{ color: "#1677ff", margin: 0, fontSize:"25px" }}>
        5
      </Title>
    </Card>
  </Col>
<Col span={6}>
    <Card style={{ padding: "12px", borderRadius: "8px", backgroundColor:"blanchedalmond" }}>
      <Text style={{ fontSize: "14px" }}>Teachers Level 3</Text>
      <Title level={4} style={{ color: "#1677ff", margin: 0, fontSize:"25px" }}>
       10
      </Title>
    </Card>
  </Col>
</Row>

      {/* Filters */}
      <Card style={{ marginTop: 25 }}>
        <Row gutter={16}>
          <Col span={8}>
            <Search placeholder="Search teachers..." allowClear 
             onChange={(e) => setSearchTerm(e.target.value)}
             />
          </Col>

          <Col span={8}>
            <Select
              defaultValue="all"
              style={{ width: "100%" }}
              options={[
                { value: "all", label: "All Shift" },
                { value: "Morning", label: "Morning" },
                { value: "Afternoon", label: "Afternoon" },
                { value: "Evening", label: "Evening" }
              ]}
            />
          </Col>

          <Col span={8}>
            <Select
              defaultValue="all"
              style={{ width: "100%" }}
              options={[
                { value: "all", label: "All Address" },
                { value: "PP", label: "PP" },
                { value: "SR", label: "SR" },
                { value: "SVR", label: "SVR" },
                { value: "KP", label: "KP" }
              ]}
              // onChange={(value) => setStatusFilter(value)}
            />
          </Col>
        </Row>
      </Card>
         {/* Teacher Table */}
   <Table
      columns={columns}
    //  dataSource={teachers}   // always an array
      dataSource={filteredTeachers}
      rowKey="TeacherCode"
      pagination={{ pageSize: 5 }}
    />
    </div>
  );
};

export default TeacherManagement;