import React, { useEffect, useState } from "react";
import {
  Modal,
  Form,
  Select,
  Row,
  Col,
  Button,
  message,
  Input
} from "antd";

import api from "../../../Api/indext";

const FeeForm = ({
  open,
  onCancel,
  onSubmit,
  initialValues,
  mode,
}) => {

  const [form] = Form.useForm();

  const [ClassName, SetClassName] = useState([]);

  const fetchClassesName = async () => {

    try {

      const token =
        localStorage.getItem("accessToken");

      const res = await api.get(
        "/classes/select",
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );

      SetClassName(res.data);

    } catch (error) {

      console.error(error);

      message.error(
        "Failed to load class name"
      );
    }
  };

  useEffect(() => {
    fetchClassesName();
  }, []);

  useEffect(() => {

  if (open) {

    if (
      mode === "add"
    ) {

      form.resetFields();

    } else if (
      initialValues
    ) {

      form.setFieldsValue({
        ...initialValues,
      });

    }

  }

}, [
  open,
  mode,
  initialValues,
  form
]);

  const handleFinish = (values) => {

    const formData = {
      ...values,
    };

    onSubmit(formData);
  };

  return (
    <Modal
      open={open}
      onCancel={onCancel}
      footer={null}
      width={800}
      destroyOnHidden
      title={
        mode === "update"
          ? "Update Fee"
          : mode === "view"
          ? "View Fee"
          : "Add Fee"
      }
    >

      <Form
        form={form}
        layout="vertical"
        onFinish={handleFinish}
      >

        <Row gutter={20}>

          <Col span={12}>
            <Form.Item
              label="ឈ្មោះថ្នាក់រៀន"
              name="ClassId"
              rules={[{ required: true }]}
            >

              <Select placeholder="ជ្រើសរើសថ្នាក់រៀន">

                {ClassName.map(item => (
                  <Select.Option
                    key={item.Id}
                    value={item.Id}
                  >
                    {item.ClassName}
                  </Select.Option>
                ))}

              </Select>

            </Form.Item>
          </Col>

          <Col span={12}>
            <Form.Item
              name="FeeName"
              label="Fee Name"
              rules={[
                {
                  required: true,
                }
              ]}
            >
              <Input />
            </Form.Item>
          </Col>

          <Col span={12}>
            <Form.Item
              label="ចំនួនទឹកប្រាក់សរុប"
              name="Amount"
              rules={[{ required: true }]}
            >

              <Input />

            </Form.Item>
          </Col>

          <Col span={12}>
            <Form.Item
              label="Description"
              name="Description"
            >

              <Input.TextArea rows={4} />

            </Form.Item>
          </Col>

        </Row>

        {mode !== "view" && (
          <div
            style={{
              display: "flex",
              justifyContent: "flex-end",
              marginTop: 20,
            }}
          >

            <Button
              onClick={onCancel}
              style={{ marginRight: 10 }}
            >
              Cancel
            </Button>

            <Button
              type="primary"
              htmlType="submit"
            >
              {mode === "update"
                ? "Update"
                : "Save"}
            </Button>

          </div>
        )}

      </Form>

    </Modal>
  );
};

export default FeeForm;