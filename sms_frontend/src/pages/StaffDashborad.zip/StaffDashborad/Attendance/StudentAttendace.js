import React, { useState,useEffect } from "react";
import { Row, Col, Card, Typography, Input, DatePicker,
   Select, Table, Tag, Space ,selectedDate,Button,message,Statistic
  } from "antd";
import {
  CheckCircleOutlined,
  CloseCircleOutlined,
  ClockCircleOutlined,
  SearchOutlined,
  
} from "@ant-design/icons";
import api from "../../../Api/indext";
import dayjs from 'dayjs';
const { Title, Text } = Typography;
const { Option } = Select;

// 1. Translations Object (Keep this consistent with your StaffDashboard)
const translations = {
  en: {
    title: "Attendance",
    subtitle: "Track and manage student attendance",
    present: "Present",
    absent: "Absent",
    late: "Late",
    rate: "Attendance Rate",
    search: "Search by name, ID, or course...",
    allLevel: "All Levels",
    student: "STUDENT",
    course: "COURSE",
    date: "DATE",
    status: "STATUS",
  },
  kh: {
    title: "វត្តមាន",
    subtitle: "តាមដាន និងគ្រប់គ្រងវត្តមានសិស្ស",
    present: "វត្តមាន",
    absent: "អវត្តមាន",
    late: "យឺត",
    rate: "អត្រាវត្តមាន",
    search: "ស្វែងរកតាមឈ្មោះ អាយឌី ឬវគ្គសិក្សា...",
    allLevel: "គ្រប់កម្រិត",
    student: "សិស្ស",
    course: "វគ្គសិក្សា",
    date: "កាលបរិច្ឆេទ",
    status: "ស្ថានភាព",
  },
};
// ឧទាហរណ៍ប្រើបណ្ណាល័យ Ant Design Cards ដូចក្នុងរូប



export default function Attendance() {
  // Get language from localStorage (same as your dashboard)
  const [lang] = useState(localStorage.getItem("language") || "en");
  const t = translations[lang];
  const [stats, setStats] = useState({ present: 0, absent: 0, late: 0, attendanceRate: "0%" });
  const [ClassId, setClassId] = useState(1); // កំណត់តម្លៃ default ឬទាញពី props
  const [selectedDate, setSelectedDate] = useState(dayjs().format('YYYY-MM-DD'));
  const [attendanceStudent, setAttendanceStudent] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const fetchAttendanceStudent = async () => {
    setLoading(true);
    try {
        const token = localStorage.getItem("accessToken");
        
        // Request without filters (params)
        const res = await api.get("/attendance/student/getlist", {
            headers: { Authorization: `Bearer ${token}` },
        });

        console.log("Data from server:", res.data);

        // Check if list exists, if not, try using res.data directly
        if (res.data && res.data.list) {
            setAttendanceStudent(res.data.list);
        } else if (Array.isArray(res.data)) {
            setAttendanceStudent(res.data);
        }

    } catch (err) {
        console.error("Fetch error:", err.response?.data || err.message);
        message.error("Failed to load attendance student");
    } finally {
        setLoading(false);
    }
};
const fetchStats = async () => {
  try {
    const response = await api.get('/attendance/stu-stats', {
      params: { 
        ClassId: ClassId, // Passed from your state
        date: selectedDate // Passed from your state (YYYY-MM-DD)
      }
    });
    setStats(response.data);
  } catch (error) {
    console.error("Search Error:", error);
  }
};

//  search + status filter done
    const filteredAttendance = attendanceStudent.filter((attendance) => {
    const matchesSearch =
      (attendance.AttendanceDate && attendance.AttendanceDate.toString().includes(searchTerm)) ||
      (attendance.StudentId && attendance.StudentId.toString().includes(searchTerm));

    const matchesStatus =
      statusFilter === "all" ||
      (statusFilter === "active" && attendance.Status === "Active") ||
      (statusFilter === "inactive" && attendance.Status === "Inactive");

    return matchesSearch && matchesStatus;
  });
useEffect(() => {
    fetchStats();
    fetchAttendanceStudent();
}, [ClassId, selectedDate]); // Empty array means it runs once when the page opens


  /* ------------------ TABLE COLUMNS ------------------ */
  const columns = [
  { 
    title: "Student ID", 
    dataIndex: "StudentId", // MUST match SQL column name exactly
    key: "StudentId" 
  },
  { 
    title: "Attendance Date", 
    dataIndex: "AttendanceDate", 
    key: "AttendanceDate" 
  },
  { 
    title: "Teacher Name", 
    dataIndex: "TeacherId_mark", 
    key: "TeacherId_mark" 
  },
  { 
    title: "Status", 
    dataIndex: "Status", 
    key: "Status",
    // Optional: Add color for better UI
    render: (text) => (
      <span style={{ color: text === 'Present' ? 'green' : 'red' }}>
        {text}
      </span>
    )
  },
];


  return (
    <div style={{ padding: "10px 0" }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <Title level={2} style={{ margin: 0 }}>{t.title}</Title>
        <Text type="secondary">{t.subtitle}</Text>
      </div>

      {/* Stats Cards */}
      <Row gutter={[16, 16]}>
  <Col span={4}>
    <Card title="Total " bordered={false} className="stat-card">
      <Statistic value={stats.total} precision={0}  />
    </Card>
  </Col>
  <Col span={5}>
    <Card title="Present" bordered={false} headStyle={{color: 'green'}}>
      <Statistic value={stats.present} valueStyle={{ color: '#3f8600' }} />
    </Card>
  </Col>
  <Col span={5}>
    <Card title="Absent" bordered={false} headStyle={{color: 'red'}}>
      <Statistic value={stats.absent} valueStyle={{ color: '#cf1322' }} />
    </Card>
  </Col>
  <Col span={5}>
    <Card title="Late" bordered={false} headStyle={{color: 'orange'}}>
      <Statistic value={stats.late} valueStyle={{ color: '#d48806' }} />
    </Card>
  </Col>
  <Col span={5}>
    <Card title="Permission" bordered={false} headStyle={{color: 'blue'}}>
      <Statistic value={stats.permission} valueStyle={{ color: '#096dd9' }} />
    </Card>
  </Col>
</Row>

      {/* Filters Section */}
<Card bordered={false} style={{ marginTop: 24, borderRadius: 12, background: "#f9f9f9" }}>
  <Row gutter={[16, 16]} align="bottom">
    {/* ១. កន្លែងរើស Class */}
    <Col xs={24} md={8}>
      <Text strong style={{ marginBottom: 8, display: 'block' }}>Select Class</Text>
      <Select 
        placeholder="Select a class"
        size="large" 
        style={{ width: "100%" }}
        onChange={(value) => setClassId(value)} //
      >
        <Select.Option value={1}>1</Select.Option>
        <Select.Option value={4}>4</Select.Option>
      </Select>
    </Col>

    {/* ២. កន្លែងរើស ថ្ងៃខែ */}
    <Col xs={24} md={8}>
      <Text strong style={{ marginBottom: 8, display: 'block' }}>Select Date</Text>
      <DatePicker 
        style={{ width: "100%" }} 
        size="large" 
        onChange={(date, dateString) => setSelectedDate(dateString)} //
      />
    </Col>

    {/* ៣. ប៊ូតុង Search */}
     <Col xs={24} md={8}>
        <Input prefix={<SearchOutlined />} placeholder="Search student ID..." size="large" allowClear 
            style={{ width: 280 }}
              onSearch={(value) => setSearchTerm(value)}
              onChange={(e) => setSearchTerm(e.target.value)}
          />
      </Col>
  </Row>
</Card>
      {/* Data Table */}
      <div style={{ marginTop: 24, background: "#fff", borderRadius: 12, overflow: "hidden" }}>
        <Table
         columns={columns} 
        dataSource={filteredAttendance} // This must match your useState variable name
        loading={loading} 
        rowKey={(record) => record.StudentId || record.id} 
         // dataSource={fetchAttendanceStudent}
          pagination={{ pageSize: 5 }}
          style={{ borderRadius: 12 }}
        />
      </div>
    </div>
  );
}